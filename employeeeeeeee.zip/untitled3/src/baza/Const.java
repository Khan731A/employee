package baza;

public class Const {
    public static final String TOTALMONEY_TABLE = "totalmoney";
    public static final String TOTAL_MONEY = "totalmoney";

    public static final String PROJECT_TABLE = "project";
    public static final String PROJECT_NAME = "ProjectName";
    public static final String PROJECT_PERIOD = "ProjectPeriod";

    public static final String analysts_TABLE = "analysts";
    public static final String analysts_NAME = "Name";
    public static final String analysts_LEVEL = "Level";

    public static final String backenddevelopers_TABLE = "backenddevelopers";
    public static final String backenddevelopers_NAME = "Name";
    public static final String backenddevelopers_LEVEL = "Level";

    public static final String frontenddevelopers_TABLE = "frontenddevelopers";
    public static final String frontenddevelopers_NAME = "Name";
    public static final String frontenddevelopers_LEVEL = "Level";

    public static final String dataengineers_TABLE = "dataengineers";
    public static final String dataengineers_NAME = "Name";
    public static final String dataengineers_LEVEL = "Level";

    public static final String lawyers_TABLE = "lawyers";
    public static final String lawyers_NAME = "Name";
    public static final String lawyers_LEVEL = "Level";

    public static final String marketers_TABLE = "marketers";
    public static final String marketers_NAME = "Name";
    public static final String marketers_LEVEL = "Level";

    public static final String projectmanagers_TABLE = "projectmanagers";
    public static final String projectmanagers_NAME = "Name";
    public static final String projectmanagers_LEVEL = "Level";

    public static final String accountance_TABLE = "accountance";
    public static final String accountance_NAME = "Name";
    public static final String accountance_LEVEL = "Level";
}
