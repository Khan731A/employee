package baza;

import java.util.Scanner;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.SQLException;

public class Main {

    public static void main(String[] args) {
        int totalmoney = 0;
        Database DB = new Database();
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter project name.");
        String project_name = sc.next();
        System.out.println("Enter project period.");
        int project_period = sc.nextInt();
        Input project = new Input(project_name, project_period);
        DB.addProject(project);

        System.out.println("Enter number of accountance.");
        int project_acc = sc.nextInt();
        for(int i=0; i<project_acc; i++){
            System.out.println("Enter employee's name.");
            String name = sc.next();
            System.out.println("Enter employee's level");
            int lvl = sc.nextInt();
            Input project1 = new Input(name, lvl);
            DB.addAccountance(project1);
            totalmoney += project_period*lvl*50000;
        }

        System.out.println("Enter number of project managers.");
        int project_managers = sc.nextInt();
        for(int i=0; i<project_managers; i++){
            System.out.println("Enter employee's name.");
            String name = sc.next();
            System.out.println("Enter employee's level");
            int lvl = sc.nextInt();
            Input project2 = new Input(name, lvl);
            DB.addProjectManagers(project2);
            totalmoney += project_period*lvl*50000;
        }

        System.out.println("Enter number of lawyers.");
        int project_lawyers = sc.nextInt();
        for(int i=0; i<project_lawyers; i++){
            System.out.println("Enter employee's name.");
            String name = sc.next();
            System.out.println("Enter employee's level");
            int lvl = sc.nextInt();
            Input project3 = new Input(name, lvl);
            DB.addLawyers(project3);
            totalmoney += project_period*lvl*50000;
        }

        System.out.println("Enter number of marketers.");
        int project_marketers = sc.nextInt();
        for(int i=0; i<project_marketers; i++){
            System.out.println("Enter employee's name.");
            String name = sc.next();
            System.out.println("Enter employee's level");
            int lvl = sc.nextInt();
            Input project4 = new Input(name, lvl);
            DB.addMarketers(project4);
            totalmoney += project_period*lvl*50000;
        }

        System.out.println("Enter number of data engineers.");
        int project_data_engineers = sc.nextInt();
        for(int i=0; i<project_data_engineers; i++){
            System.out.println("Enter employee's name.");
            String name = sc.next();
            System.out.println("Enter employee's level");
            int lvl = sc.nextInt();
            Input project5 = new Input(name, lvl);
            DB.addDataEngineers(project5);
            totalmoney += project_period*lvl*50000;
        }

        System.out.println("Enter number of backend developers.");
        int project_back_devs = sc.nextInt();
        for(int i=0; i<project_back_devs; i++){
            System.out.println("Enter employee's name.");
            String name = sc.next();
            System.out.println("Enter employee's level");
            int lvl = sc.nextInt();
            Input project6 = new Input(name, lvl);
            DB.addBack(project6);
            totalmoney += project_period*lvl*50000;
        }

        System.out.println("Enter number of frontend developers.");
        int project_front_devs = sc.nextInt();
        for(int i=0; i<project_front_devs; i++){
            System.out.println("Enter employee's name.");
            String name = sc.next();
            System.out.println("Enter employee's level");
            int lvl = sc.nextInt();
            Input project7 = new Input(name, lvl);
            DB.addFront(project7);
            totalmoney += project_period*lvl*50000;
        }

        System.out.println("Enter number of analysts.");
        int project_analysts = sc.nextInt();
        for(int i=0; i<project_analysts; i++){
            System.out.println("Enter employee's name.");
            String name = sc.next();
            System.out.println("Enter employee's level");
            int lvl = sc.nextInt();
            Input project8 = new Input(name, lvl);
            DB.addAnalysts(project8);
            totalmoney += project_period*100000+lvl*50000;
        }

        System.out.println("Your project name is: " + project_name);
        System.out.println("Your project period is: " + project_period);
        System.out.println("Number of accountance: " + project_acc);
        try {
            Statement statement = DB.getDbConnection().createStatement();
            ResultSet resultSet = statement.executeQuery("select * from employees.accountance");
            while(resultSet.next()){
                Input input = new Input();
                input.setProject_name(resultSet.getString(1));
                input.setProject_period(resultSet.getInt(2));
                System.out.println(input);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }

        System.out.println("Number of project managers: " + project_managers);
        try {
            Statement statement = DB.getDbConnection().createStatement();
            ResultSet resultSet = statement.executeQuery("select * from employees.projectmanagers");
            while(resultSet.next()){
                Input input = new Input();
                input.setProject_name(resultSet.getString(1));
                input.setProject_period(resultSet.getInt(2));
                System.out.println(input);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }

        System.out.println("Number of lawyers: " + project_lawyers);
        try {
            Statement statement = DB.getDbConnection().createStatement();
            ResultSet resultSet = statement.executeQuery("select * from employees.lawyers");
            while(resultSet.next()){
                Input input = new Input();
                input.setProject_name(resultSet.getString(1));
                input.setProject_period(resultSet.getInt(2));
                System.out.println(input);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }

        System.out.println("Number of marketers: " + project_marketers);
        try {
            Statement statement = DB.getDbConnection().createStatement();
            ResultSet resultSet = statement.executeQuery("select * from employees.projectmanagers");
            while(resultSet.next()){
                Input input = new Input();
                input.setProject_name(resultSet.getString(1));
                input.setProject_period(resultSet.getInt(2));
                System.out.println(input);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }

        System.out.println("Number of data engineers: " + project_data_engineers);
        try {
            Statement statement = DB.getDbConnection().createStatement();
            ResultSet resultSet = statement.executeQuery("select * from employees.dataengineers");
            while(resultSet.next()){
                Input input = new Input();
                input.setProject_name(resultSet.getString(1));
                input.setProject_period(resultSet.getInt(2));
                System.out.println(input);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }

        System.out.println("Number of backend developers: " + project_back_devs);
        try {
            Statement statement = DB.getDbConnection().createStatement();
            ResultSet resultSet = statement.executeQuery("select * from employees.backenddevelopers");
            while(resultSet.next()){
                Input input = new Input();
                input.setProject_name(resultSet.getString(1));
                input.setProject_period(resultSet.getInt(2));
                System.out.println(input);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }

        System.out.println("Number of frontend developers: " + project_front_devs);
        try {
            Statement statement = DB.getDbConnection().createStatement();
            ResultSet resultSet = statement.executeQuery("select * from employees.frontenddevelopers");
            while(resultSet.next()){
                Input input = new Input();
                input.setProject_name(resultSet.getString(1));
                input.setProject_period(resultSet.getInt(2));
                System.out.println(input);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
        System.out.println("Number of analysts: " + project_analysts);
        try {
            Statement statement = DB.getDbConnection().createStatement();
            ResultSet resultSet = statement.executeQuery("select * from employees.analysts");
            while(resultSet.next()){
                Input input = new Input();
                input.setProject_name(resultSet.getString(1));
                input.setProject_period(resultSet.getInt(2));
                System.out.println(input);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
        System.out.println("Total cost of project is: " + totalmoney);

    }
}
