package baza;

public class Input {

    private String project_name;
    private int project_period;

    Input(){};

    public Input(String project_name, int project_period) {
        this.project_name = project_name;
        this.project_period = project_period;
    }

    public String getProject_name() {
        return project_name;
    }
    public void setProject_name(String project_name) {
        this.project_name = project_name;
    }

    public int getProject_period() {
        return project_period;
    }
    public void setProject_period(int project_period) {
        this.project_period = project_period;
    }

    @Override
    public String toString() {
        return getClass().getSimpleName() + "{Name: " + project_name
                + ", Level: " + project_period
                + ", Lastname: " + "}";
    }
}
