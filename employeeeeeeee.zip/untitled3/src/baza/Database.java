package baza;

import java.sql.*;

    public class Database extends Configs{
        Connection dbConnection;
        public Connection getDbConnection()
                throws ClassNotFoundException, SQLException{
            String connectionString = "jdbc:mysql://" + dbHost + ":"
                    + dbPort + "/" + dbName;

            Class.forName("com.mysql.cj.jdbc.Driver");

            dbConnection = DriverManager.getConnection(connectionString,
                    dbUser, dbPass);

            return dbConnection;
        }

        public void addProject(Input project){
            String insert = "INSERT INTO employees." + Const.PROJECT_TABLE + "(" +
                    Const.PROJECT_NAME + ',' + Const.PROJECT_PERIOD + ")" + "VALUES(?,?)";
            try {
                PreparedStatement prSt = getDbConnection().prepareStatement(insert);
                prSt.setString(1, project.getProject_name());
                prSt.setInt(2, project.getProject_period());

                prSt.executeUpdate();
            } catch (SQLException e) {
                e.printStackTrace();
            } catch (ClassNotFoundException e) {
                e.printStackTrace();
            }
        }

        public void addAccountance(Input project){
            String insert = "INSERT INTO employees." + Const.accountance_TABLE + "(" +
                    Const.accountance_NAME + ',' + Const.accountance_LEVEL + ")" + "VALUES(?,?)";
            try {
                PreparedStatement prSt = getDbConnection().prepareStatement(insert);
                prSt.setString(1, project.getProject_name());
                prSt.setInt(2, project.getProject_period());

                prSt.executeUpdate();
            } catch (SQLException e) {
                e.printStackTrace();
            } catch (ClassNotFoundException e) {
                e.printStackTrace();
            }
        }

        public void addProjectManagers(Input project){
            String insert = "INSERT INTO employees." + Const.projectmanagers_TABLE + "(" +
                    Const.projectmanagers_NAME + ',' + Const.projectmanagers_LEVEL + ")" + "VALUES(?,?)";
            try {
                PreparedStatement prSt = getDbConnection().prepareStatement(insert);
                prSt.setString(1, project.getProject_name());
                prSt.setInt(2, project.getProject_period());

                prSt.executeUpdate();
            } catch (SQLException e) {
                e.printStackTrace();
            } catch (ClassNotFoundException e) {
                e.printStackTrace();
            }
        }

        public void addLawyers(Input project){
            String insert = "INSERT INTO employees." + Const.lawyers_TABLE + "(" +
                    Const.lawyers_NAME + ',' + Const.lawyers_LEVEL + ")" + "VALUES(?,?)";
            try {
                PreparedStatement prSt = getDbConnection().prepareStatement(insert);
                prSt.setString(1, project.getProject_name());
                prSt.setInt(2, project.getProject_period());

                prSt.executeUpdate();
            } catch (SQLException e) {
                e.printStackTrace();
            } catch (ClassNotFoundException e) {
                e.printStackTrace();
            }
        }

        public void addMarketers(Input project){
            String insert = "INSERT INTO employees." + Const.marketers_TABLE + "(" +
                    Const.marketers_NAME + ',' + Const.marketers_LEVEL + ")" + "VALUES(?,?)";
            try {
                PreparedStatement prSt = getDbConnection().prepareStatement(insert);
                prSt.setString(1, project.getProject_name());
                prSt.setInt(2, project.getProject_period());

                prSt.executeUpdate();
            } catch (SQLException e) {
                e.printStackTrace();
            } catch (ClassNotFoundException e) {
                e.printStackTrace();
            }
        }

        public void addDataEngineers(Input project){
            String insert = "INSERT INTO employees." + Const.dataengineers_TABLE + "(" +
                    Const.dataengineers_NAME + ',' + Const.dataengineers_LEVEL + ")" + "VALUES(?,?)";
            try {
                PreparedStatement prSt = getDbConnection().prepareStatement(insert);
                prSt.setString(1, project.getProject_name());
                prSt.setInt(2, project.getProject_period());

                prSt.executeUpdate();
            } catch (SQLException e) {
                e.printStackTrace();
            } catch (ClassNotFoundException e) {
                e.printStackTrace();
            }
        }

        public void addFront(Input project){
            String insert = "INSERT INTO employees." + Const.frontenddevelopers_TABLE + "(" +
                    Const.frontenddevelopers_NAME + ',' + Const.frontenddevelopers_LEVEL + ")" + "VALUES(?,?)";
            try {
                PreparedStatement prSt = getDbConnection().prepareStatement(insert);
                prSt.setString(1, project.getProject_name());
                prSt.setInt(2, project.getProject_period());

                prSt.executeUpdate();
            } catch (SQLException e) {
                e.printStackTrace();
            } catch (ClassNotFoundException e) {
                e.printStackTrace();
            }
        }

        public void addBack(Input project){
            String insert = "INSERT INTO employees." + Const.backenddevelopers_TABLE + "(" +
                    Const.backenddevelopers_NAME + ',' + Const.backenddevelopers_LEVEL + ")" + "VALUES(?,?)";
            try {
                PreparedStatement prSt = getDbConnection().prepareStatement(insert);
                prSt.setString(1, project.getProject_name());
                prSt.setInt(2, project.getProject_period());

                prSt.executeUpdate();
            } catch (SQLException e) {
                e.printStackTrace();
            } catch (ClassNotFoundException e) {
                e.printStackTrace();
            }
        }

        public void addAnalysts(Input project){
            String insert = "INSERT INTO employees." + Const.analysts_TABLE + "(" +
                    Const.analysts_NAME + ',' + Const.analysts_LEVEL + ")" + "VALUES(?,?)";
            try {
                PreparedStatement prSt = getDbConnection().prepareStatement(insert);
                prSt.setString(1, project.getProject_name());
                prSt.setInt(2, project.getProject_period());

                prSt.executeUpdate();
            } catch (SQLException e) {
                e.printStackTrace();
            } catch (ClassNotFoundException e) {
                e.printStackTrace();
            }
        }

    }

